const sql = require("mssql");

const config = {
  server: ".", // Use '.' for local shared memory connection
  database: "testdb", // Replace with your actual database name
  user: "sa", // SQL Server username
  password: "Mtsl@123", // SQL Server password
  options: {
    encrypt: false, // No encryption needed for local connections
    trustServerCertificate: true, // Disables certificate validation
  },
};

async function run() {
  let pool;
  try {
    pool = await sql.connect(config);
    console.log("Successfully connected to SQL Server!");

    // Run a test query
    const result = await pool.request().query("SELECT 1 AS Test");
    console.log("Test Query Result:", result.recordset);
  } catch (err) {
    console.error("SQL Server connection error:", err);
  } finally {
    if (pool) {
      await pool.close();
    }
  }
}

run().catch(console.error);
