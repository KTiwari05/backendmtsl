const UserModel = require("../models/user.model");
const jwt = require("jsonwebtoken");

class UserService {
  static async registerUser(email, password) {
    try {
      const createUser = new UserModel({ email, password });
      return await createUser.save();
    } catch (err) {
      throw err;
    }
  }

  static async checkUser(email) {
    try {
      return await UserModel.findOne({ email });
    } catch (err) {
      throw err;
    }
  }

  static async generateToken(tokenData, secretKey, expiresIn) {
    return jwt.sign(tokenData, secretKey, { expiresIn });
  }
}

module.exports = UserService;
